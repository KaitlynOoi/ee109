#include <avr/io.h>

#include "adc.h"


void adc_init(void)
{
    // Initialize the ADC

}

uint8_t adc_sample(uint8_t channel)
{
    // Set ADC input mux bits to 'channel' value

    // Convert an analog input and return the 8-bit result

}
