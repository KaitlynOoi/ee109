/********************************************
 *
 *  Name:
 *  Email:
 *  Section:
 *  Assignment: Lab 7 - ADC and PWM
 *
 ********************************************/

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

#include "lcd.h"
#include "adc.h"

int main(void)
{

    // Initialize the LCD


    // Initialize the ADC


    // Initialize TIMER2


    // Write splash screen and delay for 1 second


    // Use this "while (1)" loop ONLY for doing Tasks 2 and 3
    while (1) {
	// Use adc_sample to read ADC value for buttons or potentiometer

	// Use snprintf and lcd_stringout to display number on LCD

    }

    while (1) {                 // Loop forever
	// Check buttons and determine state


	// Change output based on state
        // If RIGHT or LEFT button pressed, move servo accordingly
	// If SELECT button pressed read potentiometer ADC channel
	//    Convert ADC value to OCR2A number for PWM signal



        // Display the PWM value on the LCD


    }

    return 0;   /* never reached */
}


/*
  timer2_init - Initialize Timer/Counter2 for Fast PWM
*/
void timer2_init(void)
{
    // Add code to initialize TIMER2

}
