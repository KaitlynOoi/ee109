/********************************************
 *
 *  Name:
 *  Email:
 *  Section:
 *  Assignment: Lab 5 - Timers
 *
 ********************************************/

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "lcd.h"

void debounce(uint8_t);
void timer1_init(void);
void timer1_start(void);
void timer1_stop(void);

volatile uint8_t tens, ones, tenths;
volatile uint8_t time_changed;  // Flag that the time has changed

void debounce(uint8_t);

enum states { PAUSE, RUN, LAPPED };

void timer1_init(void)
{
    TCCR1B |= (1 << WGM12);     // Set for CTC mode using OCR1A for the modulus
    TIMSK1 |= (1 << OCIE1A);    // Enable CTC interrupt

    ????                        // Set the counter modulus correctly
}

void timer1_start(void)
{
    ????                        // Set prescaler correctly, starts timer
}

void timer1_stop(void)
{
    ????                        // Set prescaler for none, stops timer
}

int main(void) {

    uint8_t state = PAUSE;      // Start off in the PAUSE state

    // Initialize the LCD and TIMER1
    lcd_init();
    timer1_init();

// This code is only executed for the "timer_test" of TASK 3
#ifdef TASK3
    DDRC |= (1 << PC5);
    timer1_start();
    sei();
    while (1) {}
#endif

    // Enable pull-ups for buttons
    PORTC |= ((1 << PC2) | (1 << PC4));

    // Show the splash screen
    
    // Add code here for Task 1, writing the splashscreen


    lcd_moveto(0, 0);           // Show 0.0 for the initial time
    lcd_stringout(" 0.0");

    // Enable interrupts
    sei();			// Enable interrupts

    while (1) {                 // Loop forever
	uint8_t ss_button, lr_button;

	// Read the buttons
	ss_button = (PINC & (1 << PC2)) == 0;  // Read the Start_Stop button
	lr_button = (PINC & (1 << PC4)) == 0;  // Read the Lapped_Reset button

	// Determine which state we are in
	if (state == PAUSE) {               // PAUSE state
	    if (ss_button) {
		timer1_start();             // Start the timer
		state = RUN;                // Move to RUN state via debouncing
		debounce(PC2);              // Debounce the Start_Stop button
	    }
	    else if (lr_button) {
		TCNT1 = 0;                  // Clear the timer count to zero
		tens = ones = tenths = 0;
		lcd_moveto(0, 0);
		lcd_stringout(" 0.0");
	    }
	}
	else if (state == RUN) {            // RUN state
	    if (ss_button) {
		timer1_stop();              // Stop the timer
		state = PAUSE;              // Move to the PAUSE state
		debounce(PC2);              // Debounce the Start_Stop button
	    }
	    else if (lr_button) {
		state = LAPPED;             // Move to the LAPPED state
		debounce(PC4);              // Debounce the Lap_Reset button
	    }
	}
	else if (state == LAPPED) {         // LAPPED state
	    if (ss_button || lr_button) {   // Either button takes us to RUN
		state = RUN;                // Move to the RUN state
		if (ss_button)
		    debounce(PC2);          // Debounce the Start_Stop button
		else
		    debounce(PC4);          // Debounce the Lap_Reset button
	    }
	}

	// If in RUN state and time has changed write time to LCD
	if (time_changed && state == RUN) {
	    time_changed = 0;
	    lcd_moveto(0, 0);
	    if (tens != 0)      // Get rid of leading zeros
		lcd_writedata(tens + '0');
	    else
		lcd_writedata(' ');
	    lcd_writedata(ones + '0');
	    lcd_writedata('.');
	    lcd_writedata(tenths + '0');
	}

    }

    return 0;   /* never reached */
}

/* ----------------------------------------------------------------------- */

void debounce(uint8_t bit)
{
    _delay_ms(5);
    while((PINC & (1 << bit)) == 0);
    _delay_ms(5);
}

/* ----------------------------------------------------------------------- */

ISR(TIMER1_COMPA_vect)
{
#ifdef TASK3
    // For Task 3, the ISR only executes this code to flip the PC5 bit
    PORTC ^= (1 << PC5);
#else
    // Increment the time
    tenths++;
    if (tenths == 10) {
	tenths = 0;
	ones++;
	if (ones == 10) {
	    ones = 0;
	    tens++;
	    if (tens == 6) {
		tenths = 0;
		ones = 0;
		tens = 0;
	    }
	}
    }
    time_changed = 1;
#endif
}
