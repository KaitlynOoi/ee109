#include <avr/io.h>
#include <util/delay.h>

#include "lcd.h"

char pressed(void);

char string[] = "Replace this with a string of at least 40 characters";

enum {LEFT = 0, RIGHT = 1};

int main(void) {
    unsigned char state = RIGHT;
    unsigned char start = 0;
    unsigned char i, length, cnt = 0;

    // Turn on pull ups for input buttons


    lcd_init();
    lcd_writecommand(0x01);     // Clear the screen

    for (i = 0; i < 16; i++) {
 	   lcd_writedata(string[i]);
    }

    while (1) {

        if (cnt == ?? ) {     // Provide the comparison constant
            // Add code to update state based on a button press






        }
        else if(cnt == ?? ) {     // Provide the comparison constant
            // Add code to determine the starting position
            // and then display the appropriate substring







            cnt = 0;
        }
        cnt++;
        _delay_ms( ?? );   // Insert an approprite delay
	}
    return 0;   /* never reached */
}

char pressed()
{
    if ((PINC & (1 << 2)) == 0) {
        _delay_ms(5);
	while ((PINC & (1 << 2)) == 0) { }
	return 1;
    }
    else
	return 0;
}
