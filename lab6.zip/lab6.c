#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <avr/interrupt.h>

#include "lcd.h"

void timer1_init(void);
void play_tone(uint16_t, uint16_t);

volatile uint8_t new_state, old_state;
volatile uint8_t changed;       // Flag that count changed
volatile int16_t count = 20;	// Count to display
volatile uint16_t buzz_count;   // How many transitions the ISR has to do
volatile uint8_t buzzing;       // Flag that tone is being played

int main(void) {
    uint8_t bits, a, b;
    uint8_t i;
    char ostr[20];
    uint16_t tone_length;
    // Frequencies for tones from 400Hz to 1600Hz in 50Hz steps (25 tones)
    uint16_t frequency[25];

    // Initialize appropriate DDR and PORT registers
    PORTC |= (1 << PC5 | 1 << PC1); // Enable pull-ups on PC5, PC1
    DDRB |= (1 << PB4);         // Set PORTB bit for buzzer output

    PORTD |= (1 << PD2);        // Turn on pull-ups for button

    timer1_init();              // Inititialize TIMER1 for tones

    lcd_init();                 // Initialize the LCD

    sei();                      // Enable interrupts

    // Add code here to write the splash screen

    // Add a 1 second delay so the splash screen can be seen

    // Add command to clear the screen after the delay


    // Set up frequencies
    for (i = 0; i < 25; i++)
	frequency[i] = i * 50 + 400;

    // Determine the intial state
    bits = PINC;
    a = bits & (1 << PC1);
    b = bits & (1 << PC5);

    if (!b && !a)
	old_state = 0;
    else if (!b && a)
	old_state = 1;
    else if (b && !a)
	old_state = 2;
    else
	old_state = 3;

    new_state = old_state;

    while (1) {                 // Loop forever
	bits = PINC;		// Read the two encoder inputs at the same time
	a = bits & (1 << PC1);  // a = LSB of state number
	b = bits & (1 << PC5);  // b = MSB of state number

	if (old_state == 0) {
	    if (a) {
		new_state = 1;
		count++;
	    }
	    else if (b) {
		new_state = 2;
		count--;
	    }
	}
	else if (old_state == 1) {
	    if (!a) {
		new_state = 0;
		count--;
	    }
	    else if (b) {
		new_state = 3;
		count++;
	    }
	}
	else if (old_state == 2) {
	    if (a) {
		new_state = 3;
		count--;
	    }
	    else if (!b) {
		new_state = 0;
		count++;
	    }
	}
	else {   // old_state = 3
	    if (!a) {
		new_state = 2;
		count++;
	    }
	    else if (!b) {
		new_state = 1;
		count--;
	    }
	}

	if (new_state != old_state) {
	    changed = 1;
	    old_state = new_state;
	}

        if (changed) { // Did encoder change the count?
	    changed = 0;
	    if (count > 80)
		count = 80;
	    else if (count < 10)
		count = 10;

            snprintf(ostr, 5, "%4d", count);
            lcd_moveto(1, 0);
            lcd_stringout(ostr);    // Print value of count
        }

	// See if button was pressed to play the sequence
	if ((PIND & (1 << PD2)) == 0) {
	    tone_length  = count * 100 / 25;  // Millisecs for each tone
	    for (i = 0; i < 25; i++)
		play_tone(frequency[i], tone_length);
	}

    }
}

/*
  play_tone - Plays a single tone on the buzzer at frequency "freq" and
  for "length" milliseconds
*/
void play_tone(uint16_t freq, uint16_t length)
{
    uint32_t temp;

    // Wait for previous tone to complete
    while (buzzing == 1) {}
    /*
      freq is the number of cycles/sec of the tone, so
      the number of transitions/sec would be freq * 2.
      Want to play the tone for "length" milliseconds.
      The number of transitions should be given by
	 freq * 2 * length / 1000
    */
    temp = freq;
    temp = temp * 2 * length / 1000;
    buzz_count = temp;
    /*
      Find counter modulo.  The number of system clocks
      for half a period using a prescalar of 1 is
      16,000,000 / (freq * 2) = 8000000/freq
    */
    TCNT1 = 0;
    OCR1A = 8000000 / freq - 1;
    TCCR1B |= (0b001 << CS10);  // Set prescaler to /1, starts TIMER1

    buzzing = 1;    // Flag that the buzzing is going on
}

void timer1_init()
{
    // Add lines to initialize TIMER1



}

/*
  ISR for TIMER1.  Used for buzzer output delays
*/
ISR(TIMER1_COMPA_vect)
{
    // Add lines for generating the output signal




}
