/********************************************
*
*  Name:
*  Email:
*  Lab section:
*  Assignment: Lab 3 - Arduino Input and Output
*
********************************************/

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{

    // Initialize appropriate DDR registers

    // Initialize the LED output to 0

    // Enable the pull-up resistors for the 3 button inputs 

    // Loop forever
    while (1) {                 
	//  Read the state of the three buttons to 
	//  see how many are presssed.
    


	// If less than 2 pressed blink the LED at 5Hz rate
        // If 2 or more pressed blink the LED at 1Hz rate



    }

    return 0;   /* never reached */
}
